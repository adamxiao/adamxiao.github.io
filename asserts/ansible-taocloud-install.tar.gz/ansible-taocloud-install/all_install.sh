#!/bin/bash

set -e

ansible-playbook init_nodes.yml
ansible-playbook setup_ssh_trust.yml
ansible-playbook suzaku_install.yml
ansible-playbook suzaku_create_cluster.yml
ansible-playbook console_install.yml
