# 大道云存储安装说明

## 一键安装

- 配置 hosts 文件
- 配置任务脚本

#### ansible前置条件

安装ansible, sshpass
```
yum install ansible sshpass
```

目标系统有点问题
```
no_target_syslog = True
```

安装 => 未成功
```
sudo dnf install -y python3-systemd
```

#### 一键安装脚本

参考威固写的安装部署脚本

=> 需要先修改 ./vgscript/hosts 配置文件
```
bash ./all-install.sh --first-node-ip 10.90.4.108 --first-node-passwd ksvd@2025
```

6.1创建endpoint与suzaku集群

```
/opt/suzaku/suzaku/script/etcdtools.py cluster create --hosts node1,node2,node3
```

```
/opt/suzaku/suzaku/script/ans.py create --hosts node1,node2,node3 --endpoint node1,node2,node3
```
=> 这里用了ansible

集群对时
```
suzaku ans time ntpconfig -a node1
```

查看集群状态，不正常!
```
suzaku ans status
```

#### 六、前端软件安装

需要一个虚拟ip
```
node132 上安装：sh mgnt_xxx.bin  -p  vip(172.26.9.135 没有在用的) -e eno1
node133 上安装：sh mgnt_xxx.bin  -p  vip(172.26.9.135 没有在用的) -e eno2
=> 使用管理网卡名称

sh mgnt_v2.3.0.bin -p 10.90.3.34 -e enp4s1
```

登录Web UI界面,访问地址：http://10.90.3.34:8888/
admin/sysadmin

## FAQ

#### ui添加节点状态异常

每个节点的/opt/suzaku/data目录需要添加sync挂在参数

稍等会吧，我先改完看看有没有问题，虚拟机的配置比较低，服务不一定能正常启动
```
globals:
  rdma: off
  nvmf: off
  iscsi: on
  hugepage_size: 0G
  hb_timeout: 8
  rpc_timeout: 16
  lease_timeout: 8
  nic_prio: on
  io_crc: on
  hb_timeout: 4
  rpc_timeout: 6
  lease_timeout: 8

coremask:
  tgtctl:      0x2           # [1]
  logctl:      0x4           # [2]
  rangectl:    0x8           # [3]
  bactl:       0x10          # [4]
  netctl:      0x20          # [5]
  mdctl:       0x40          # [6]

layout:
  wal_local: none

networks:
  manage:
    - 10.90.3.0/24

  backend:
    - 10.90.3.0/24

  frontend:
    - 10.90.3.0/24

bactl:
  enable_aio: on

target:
  iqn: iqn.2019-03.cn.suzaku
  nqn: nqn.2019-03.cn.suzaku
  iobar_usesid: off
```
