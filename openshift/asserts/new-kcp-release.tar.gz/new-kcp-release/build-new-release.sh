org_release=${1:-hub.iefcu.cn/xiaoyun/kcp-release:4.9.25-x86-hub.iefcu.cn}

   new_kubeapi_operator=hub.iefcu.cn/xiaoyun/openshift-new-release:cluster-kube-apiserver-operator
new_controller_operator=hub.iefcu.cn/xiaoyun/openshift-new-release:cluster-kube-controller-manager-operator
      new_etcd_operator=hub.iefcu.cn/xiaoyun/openshift-new-release:cluster-etcd-operator
          new_installer=hub.iefcu.cn/xiaoyun/openshift-new-release:installer
   new_ingress_operator=hub.iefcu.cn/xiaoyun/openshift-new-release:cluster-ingress-operator
         new_service_ca=hub.iefcu.cn/xiaoyun/openshift-new-release:service-ca-operator

old_kubeapi_operator=`jq -r '.spec.tags[] | select(.name=="cluster-kube-apiserver-operator") | .from.name' ./image-references`
old_controller_operator=`jq -r '.spec.tags[] | select(.name=="cluster-kube-controller-manager-operator") | .from.name' ./image-references`
old_etcd_operator=`jq -r '.spec.tags[] | select(.name=="cluster-etcd-operator") | .from.name' ./image-references`
old_installer=`jq -r '.spec.tags[] | select(.name=="installer") | .from.name' ./image-references`
old_ingress_operator=`jq -r '.spec.tags[] | select(.name=="cluster-ingress-operator") | .from.name' ./image-references`
old_service_ca=`jq -r '.spec.tags[] | select(.name=="service-ca-operator") | .from.name' ./image-references`


sudo podman rmi $new_kubeapi_operator
sudo podman pull $new_kubeapi_operator
   new_kubeapi_operator=`sudo podman inspect --format='{{index .RepoDigests 0}}' $new_kubeapi_operator`
sudo podman rmi $new_controller_operator
sudo podman pull $new_controller_operator
new_controller_operator=`sudo podman inspect --format='{{index .RepoDigests 0}}' $new_controller_operator`
sudo podman rmi $new_etcd_operator
sudo podman pull $new_etcd_operator
      new_etcd_operator=`sudo podman inspect --format='{{index .RepoDigests 0}}' $new_etcd_operator`
sudo podman rmi $new_installer
sudo podman pull $new_installer
          new_installer=`sudo podman inspect --format='{{index .RepoDigests 0}}' $new_installer`
sudo podman rmi $new_ingress_operator
sudo podman pull $new_ingress_operator
   new_ingress_operator=`sudo podman inspect --format='{{index .RepoDigests 0}}' $new_ingress_operator`
sudo podman rmi $new_service_ca
sudo podman pull $new_service_ca
         new_service_ca=`sudo podman inspect --format='{{index .RepoDigests 0}}' $new_service_ca`


cat > Dockerfile.gen <<EOF
FROM $org_release

RUN sed -i -e "s#${old_kubeapi_operator}#${new_kubeapi_operator}#g" /release-manifests/*
RUN sed -i -e "s#${old_controller_operator}#${new_controller_operator}#g" /release-manifests/*
RUN sed -i -e "s#${old_etcd_operator}#${new_etcd_operator}#g" /release-manifests/*
RUN sed -i -e "s#${old_installer}#${new_installer}#g" /release-manifests/*
RUN sed -i -e "s#${old_ingress_operator}#${new_ingress_operator}#g" /release-manifests/*
RUN sed -i -e "s#${old_service_ca}#${new_service_ca}#g" /release-manifests/*

# spec proc
RUN sed -i -e "s#quay.kcp.cn:9443/kcp/openshift4-aarch64#hub.iefcu.cn/xiaoyun/openshift4-aarch64#g" /release-manifests/*
EOF

version="new-4.9-`date +%s`"
echo $version
sudo podman build -f ./Dockerfile.gen -t hub.iefcu.cn/xiaoyun/ocp-build:$version .

echo =====================================================
echo "TODO: push image to registry, hub.iefcu.cn/xiaoyun/ocp-build:$version"
echo =====================================================
