#!/bin/bash

set -e

top_dir=$PWD
img_ref=$PWD/image-references

build_etcd()
{

cd $top_dir/openshift-src/cluster-etcd-operator && make build

rm -rf tmpdir
mkdir -p tmpdir && cd tmpdir
install ../cluster-etcd-operator ./

org_img=`jq -r '.spec.tags[] | select(.name=="cluster-etcd-operator") | .from.name' $img_ref`
cat > ./Dockerfile.gen <<EOF
FROM $org_img

ADD ./cluster-etcd-operator /usr/bin/cluster-etcd-operator
EOF

sudo podman build -f ./Dockerfile.gen -t hub.iefcu.cn/xiaoyun/openshift-new-release:cluster-etcd-operator .

}

build_apiserver_operator()
{

cd $top_dir/openshift-src/cluster-kube-apiserver-operator/ && make build

rm -rf tmpdir
mkdir -p tmpdir && cd tmpdir
install ../cluster-kube-apiserver-operator ./

org_img=`jq -r '.spec.tags[] | select(.name=="cluster-kube-apiserver-operator") | .from.name' $img_ref`
cat > ./Dockerfile.gen <<EOF
FROM $org_img

ADD ./cluster-kube-apiserver-operator /usr/bin/cluster-kube-apiserver-operator
EOF

sudo podman build -f ./Dockerfile.gen -t hub.iefcu.cn/xiaoyun/openshift-new-release:cluster-kube-apiserver-operator .

}

build_controller_operator()
{

cd $top_dir/openshift-src/cluster-kube-controller-manager-operator/ && make build

rm -rf tmpdir
mkdir -p tmpdir && cd tmpdir
install ../cluster-kube-controller-manager-operator ./

org_img=`jq -r '.spec.tags[] | select(.name=="cluster-kube-controller-manager-operator") | .from.name' $img_ref`
cat > ./Dockerfile.gen <<EOF
FROM $org_img

ADD ./cluster-kube-controller-manager-operator /usr/bin/cluster-kube-controller-manager-operator
EOF

sudo podman build -f ./Dockerfile.gen -t hub.iefcu.cn/xiaoyun/openshift-new-release:cluster-kube-controller-manager-operator .

}

build_ingress_operator()
{

cd $top_dir/openshift-src/cluster-ingress-operator/ && make build

rm -rf tmpdir
mkdir -p tmpdir && cd tmpdir
install ../ingress-operator ./

org_img=`jq -r '.spec.tags[] | select(.name=="cluster-ingress-operator") | .from.name' $img_ref`
cat > ./Dockerfile.gen <<EOF
FROM $org_img

ADD ./ingress-operator /usr/bin/ingress-operator
EOF

sudo podman build -f ./Dockerfile.gen -t hub.iefcu.cn/xiaoyun/openshift-new-release:cluster-ingress-operator .

}

build_service_ca_operator()
{

cd $top_dir/openshift-src/service-ca-operator/ && make build

rm -rf tmpdir
mkdir -p tmpdir && cd tmpdir
install ../service-ca-operator ./

org_img=`jq -r '.spec.tags[] | select(.name=="service-ca-operator") | .from.name' $img_ref`
cat > ./Dockerfile.gen <<EOF
FROM $org_img

ADD ./service-ca-operator /usr/bin/service-ca-operator
EOF

sudo podman build -f ./Dockerfile.gen -t hub.iefcu.cn/xiaoyun/openshift-new-release:service-ca-operator .

}

build_installer()
{

cd $top_dir/openshift-src/installer/ && bash hack/build.sh

rm -rf tmpdir
mkdir -p tmpdir && cd tmpdir
install ../bin/openshift-install ./

org_img=`jq -r '.spec.tags[] | select(.name=="installer") | .from.name' $img_ref`
cat > ./Dockerfile.gen <<EOF
FROM $org_img

ADD ./openshift-install /usr/bin/openshift-install
EOF

sudo podman build -f ./Dockerfile.gen -t hub.iefcu.cn/xiaoyun/openshift-new-release:installer .

}

build_etcd
build_apiserver_operator
build_controller_operator
build_ingress_operator
build_service_ca_operator
build_installer # 注意arm架构也需要在x86平台下编译!!! (因为运行openshift-install的堡垒机是x86架构)

echo =======================================================================
echo "BUILD all image success, TODO: push to registry ======================"
echo =======================================================================
