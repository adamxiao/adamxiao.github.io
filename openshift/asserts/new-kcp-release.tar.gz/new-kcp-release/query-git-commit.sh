echo ==================================

echo cluster-kube-apiserver-operator
jq -r '.spec.tags[] | select(.name=="cluster-kube-apiserver-operator") | .annotations."io.openshift.build.commit.id"' ./image-references
echo cluster-kube-controller-manager-operator
jq -r '.spec.tags[] | select(.name=="cluster-kube-controller-manager-operator") | .annotations."io.openshift.build.commit.id"' ./image-references
echo cluster-etcd-operator
jq -r '.spec.tags[] | select(.name=="cluster-etcd-operator") | .annotations."io.openshift.build.commit.id"' ./image-references
echo installer
jq -r '.spec.tags[] | select(.name=="installer") | .annotations."io.openshift.build.commit.id"' ./image-references
echo cluster-ingress-operator
jq -r '.spec.tags[] | select(.name=="cluster-ingress-operator") | .annotations."io.openshift.build.commit.id"' ./image-references
echo service-ca-operator
jq -r '.spec.tags[] | select(.name=="service-ca-operator") | .annotations."io.openshift.build.commit.id"' ./image-references

echo ==================================

jq -r '.spec.tags[] | select(.name=="cluster-kube-apiserver-operator") | .from.name' ./image-references
jq -r '.spec.tags[] | select(.name=="cluster-kube-controller-manager-operator") | .from.name' ./image-references
jq -r '.spec.tags[] | select(.name=="cluster-etcd-operator") | .from.name' ./image-references
jq -r '.spec.tags[] | select(.name=="installer") | .from.name' ./image-references
jq -r '.spec.tags[] | select(.name=="cluster-ingress-operator") | .from.name' ./image-references
jq -r '.spec.tags[] | select(.name=="service-ca-operator") | .from.name' ./image-references

echo ==================================
