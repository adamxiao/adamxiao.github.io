# 新release制作

## arm架构新的release

基于
```
oc adm release info quay.kcp.cn:9443/kcp/kcp-release-4.9.0.5:latest
quay.kcp.cn:9443/kcp/kcp-release-4.9.0.5@sha256:987dd9a4010a1911a8839805915b47d920fd513d97c5220996a86baf6f1a69dd
=> 为方便使用, 重新提交为 hub.iefcu.cn/xiaoyun/ocp-release:kcp-release-4.9.0.5
```

#### 1.首先提取 release 的 image-references 镜像信息文件

```
oc image extract --confirm \
  --path /release-manifests/image-references:./ \
  hub.iefcu.cn/xiaoyun/ocp-release:kcp-release-4.9.0.5
```

#### 2.然后初始化相关组件源码，构建出新的镜像

然后使用相关源码, 编译构建出新的镜像
```
git submodule update --init # 初始化相关组件源码
```

然后使用脚本进行构建 TODO: arm架构需要修改一下脚本，让openshift-install容器在x86机器上构建!
(注意: 是使用podman构建，是coreos上面安装好go包就能构建了)
```
sed -i -e 's/^build_etcd$/#&/' build-new-images.sh # arm架构屏蔽编译openshift-install镜像
bash -x build-new-images.sh
```

然后将构建出来的镜像手动上传到镜像仓库
TODO: 调整镜像名, 例如hub.iefcu.cn 改为 quay.kcp.cn
```
=> TODO: 需要首先登录镜像仓库 sudo podman login hub.iefcu.cn
sudo podman images | grep openshift-new-release | grep -vw none | awk '{print $1":"$2}' | xargs -n 1 sudo podman push
```

然后在x86机器上单独构建openshift-install镜像
```
=> 重新克隆本构建脚本，然后下载相关源码
git submodule update --init openshift-src/installer
=> 注释掉 build-new-images.sh 脚本中构建其他镜像的命令
bash -x build-new-images.sh
```

#### 3.构建新的release镜像

TODO: 可能需要手动修改一下org_release变量, 以及调整hub.iefcu.cn的名称!
```
bash build-new-release.sh hub.iefcu.cn/xiaoyun/ocp-release:kcp-release-4.9.0.5
=> 以及上传到镜像仓库
```

## x86架构新的release

基本同上，只不过基于这个release制作测试
```
oc image extract --confirm \
  --path /release-manifests/image-references:./ \
  hub.iefcu.cn/xiaoyun/kcp-release:4.9.25-x86-hub.iefcu.cn
```

以及需要切换到x86的源码分支
```
git submodule foreach 'git fetch origin'
git submodule foreach 'git checkout origin/kcp-x86'
```
